import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export type CaseRow = {
  id: string;
  title: string;
  court: string | null;
  hearing_date: string;
  notes: string | null;
  status: string;
  created_at: string;
};

export type DocumentRow = {
  id: string;
  case_id: string;
  file_name: string;
  storage_path: string;
  size_bytes: number | null;
  uploaded_at: string;
};

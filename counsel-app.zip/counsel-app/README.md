# Counsel — Law Firm Case Manager

Next.js + Supabase + Vercel. Case calendar, document storage per case, and an AI legal research assistant.

## 1. Supabase setup

1. Create a project at supabase.com.
2. Open the SQL editor and run `supabase/schema.sql` (creates tables + storage bucket + RLS policies).
3. Go to Project Settings → API and copy:
   - Project URL
   - anon public key
   - service_role key (server-only, for the research API route if you log usage — optional)

## 2. Environment variables

Copy `.env.local.example` to `.env.local` and fill in:

```
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
ANTHROPIC_API_KEY=your-anthropic-api-key
```

## 3. Local dev

```
npm install
npm run dev
```

## 4. Deploy to Vercel

```
npm i -g vercel
vercel
```

Add the same three environment variables in the Vercel project settings (Settings → Environment Variables) before deploying, for both Production and Preview.

## Notes

- Auth is not included — add Supabase Auth (email/password or magic link) before putting real client data in this, since right now anyone with the URL can read/write. See "Adding auth" below.
- Document uploads go to a private Supabase Storage bucket called `case-documents`. Files are fetched via signed URLs, not public ones.
- The research assistant calls Anthropic's API from a server route (`app/api/research/route.ts`) — your API key never reaches the browser.
- The assistant is for research support only. Always verify citations against a primary source (SCC Online, Manupatra, official court sites) before relying on them in a filing.

## Adding auth (recommended before real use)

1. Enable Email auth in Supabase Auth settings.
2. Wrap the app in a login screen using `supabase.auth.signInWithOtp` or `signInWithPassword`.
3. Tighten the RLS policies in `schema.sql` to use `auth.uid()` instead of `true`.

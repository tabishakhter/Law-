-- Counsel: case management schema for Supabase

create extension if not exists "uuid-ossp";

create table if not exists cases (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  court text,
  hearing_date date not null,
  notes text,
  status text default 'open',
  created_at timestamptz default now()
);

create table if not exists documents (
  id uuid primary key default uuid_generate_v4(),
  case_id uuid references cases(id) on delete cascade,
  file_name text not null,
  storage_path text not null,
  size_bytes bigint,
  uploaded_at timestamptz default now()
);

-- Storage bucket for case documents (private)
insert into storage.buckets (id, name, public)
values ('case-documents', 'case-documents', false)
on conflict (id) do nothing;

-- Row level security
alter table cases enable row level security;
alter table documents enable row level security;

-- NOTE: these policies allow any request with the anon key to read/write.
-- Replace `true` with an auth.uid()-based check once you add Supabase Auth.
create policy "allow all on cases" on cases
  for all using (true) with check (true);

create policy "allow all on documents" on documents
  for all using (true) with check (true);

create policy "allow all on case-documents storage"
  on storage.objects for all
  using (bucket_id = 'case-documents')
  with check (bucket_id = 'case-documents');

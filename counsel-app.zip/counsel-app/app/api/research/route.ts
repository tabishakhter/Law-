import Anthropic from '@anthropic-ai/sdk';
import { NextRequest, NextResponse } from 'next/server';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      system:
        'You are a legal research assistant for a law firm. Provide concise, well-organized analysis of legal questions, relevant statutes, and case law concepts. Always note that citations should be verified against a primary source (e.g. SCC Online, Manupatra, or an official court website) before use in filings, since exact citations may be inaccurate.',
      messages,
    });

    const text = response.content
      .filter((b): b is Anthropic.TextBlock => b.type === 'text')
      .map((b) => b.text)
      .join('\n');

    return NextResponse.json({ text });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Research request failed' }, { status: 500 });
  }
}

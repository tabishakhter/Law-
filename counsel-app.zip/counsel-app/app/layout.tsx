import './globals.css';

export const metadata = {
  title: 'Counsel — case manager',
  description: 'Case calendar, documents, and legal research assistant',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

'use client';

import { useState } from 'react';
import Calendar from './components/Calendar';
import Cases from './components/Cases';
import Research from './components/Research';

type View = 'calendar' | 'cases' | 'research';

export default function Home() {
  const [view, setView] = useState<View>('calendar');

  return (
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '2.5rem 1.5rem' }}>
      <header style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: 28 }}>Counsel</h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: 4 }}>
          Case calendar, documents, and research, in one place.
        </p>
      </header>

      <nav style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border)', marginBottom: '2rem' }}>
        {(['calendar', 'cases', 'research'] as View[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            style={{
              border: 'none',
              background: 'none',
              padding: '10px 6px',
              marginRight: 16,
              borderRadius: 0,
              borderBottom: view === v ? '2px solid var(--accent)' : '2px solid transparent',
              color: view === v ? 'var(--text-primary)' : 'var(--text-secondary)',
              fontWeight: 500,
            }}
          >
            {v === 'calendar' ? 'Calendar' : v === 'cases' ? 'Cases' : 'Research assistant'}
          </button>
        ))}
      </nav>

      {view === 'calendar' && <Calendar onSelectCase={() => setView('cases')} />}
      {view === 'cases' && <Cases />}
      {view === 'research' && <Research />}
    </div>
  );
}

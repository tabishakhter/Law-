'use client';

import { useState } from 'react';

type Msg = { role: 'user' | 'assistant'; content: string };

export default function Research() {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: 'assistant',
      content:
        "I'm your legal research assistant. Ask about case law, statutes, or precedents. Always verify citations against a primary source (SCC Online, Manupatra, official court sites) before relying on them in a filing.",
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim()) return;
    const next = [...messages, { role: 'user' as const, content: input.trim() }];
    setMessages(next);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.map((m) => ({ role: m.role, content: m.content })) }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: 'assistant', content: data.text || 'No response.' }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: "Couldn't reach the research service. Try again." }]);
    }
    setLoading(false);
  }

  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxHeight: 480, overflowY: 'auto', marginBottom: '1rem' }}>
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
              maxWidth: '85%',
              background: m.role === 'user' ? 'var(--accent-bg)' : 'var(--surface)',
              border: m.role === 'user' ? 'none' : '1px solid var(--border)',
              borderRadius: 'var(--radius)',
              padding: '10px 14px',
            }}
          >
            <p style={{ margin: 0, fontSize: 14, whiteSpace: 'pre-wrap' }}>{m.content}</p>
          </div>
        ))}
        {loading && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Researching…</p>}
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <input
          style={{ flex: 1 }}
          placeholder="Ask about a statute, precedent, or legal concept"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
        />
        <button className="primary" onClick={send}>Send</button>
      </div>
    </div>
  );
}

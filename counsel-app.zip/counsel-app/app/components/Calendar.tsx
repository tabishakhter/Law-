'use client';

import { useEffect, useMemo, useState } from 'react';
import { supabase, CaseRow } from '@/lib/supabase';

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export default function Calendar({ onSelectCase }: { onSelectCase: (id: string) => void }) {
  const [cases, setCases] = useState<CaseRow[]>([]);
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  useEffect(() => {
    supabase
      .from('cases')
      .select('*')
      .order('hearing_date', { ascending: true })
      .then(({ data }) => setCases(data || []));
  }, []);

  const byDate = useMemo(() => {
    const m: Record<string, CaseRow[]> = {};
    cases.forEach((c) => {
      (m[c.hearing_date] = m[c.hearing_date] || []).push(c);
    });
    return m;
  }, [cases]);

  const today = new Date().toISOString().slice(0, 10);

  function dateStr(day: number) {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    return new Date(y, m, day).toISOString().slice(0, 10);
  }

  function cells() {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const startDay = new Date(y, m, 1).getDay();
    const numDays = new Date(y, m + 1, 0).getDate();
    const out: (number | null)[] = [];
    for (let i = 0; i < startDay; i++) out.push(null);
    for (let d = 1; d <= numDays; d++) out.push(d);
    return out;
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
        <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>←</button>
        <h2>{monthNames[cursor.getMonth()]} {cursor.getFullYear()}</h2>
        <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>→</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 6, marginBottom: 6 }}>
        {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
          <div key={d} style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-muted)' }}>{d}</div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 6 }}>
        {cells().map((day, i) => {
          if (day === null) return <div key={i} />;
          const ds = dateStr(day);
          const items = byDate[ds] || [];
          const isToday = ds === today;
          return (
            <div
              key={i}
              style={{
                minHeight: 76,
                border: isToday ? '1px solid var(--accent)' : '1px solid var(--border)',
                borderRadius: 'var(--radius)',
                padding: 6,
                background: items.length ? 'var(--accent-bg)' : 'var(--surface)',
              }}
            >
              <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 4 }}>{day}</div>
              {items.slice(0, 2).map((c) => (
                <div
                  key={c.id}
                  onClick={() => onSelectCase(c.id)}
                  style={{ fontSize: 11, color: 'var(--accent)', cursor: 'pointer', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                >
                  {c.title}
                </div>
              ))}
              {items.length > 2 && <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>+{items.length - 2} more</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

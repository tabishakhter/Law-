'use client';

import { useEffect, useState } from 'react';
import { supabase, CaseRow, DocumentRow } from '@/lib/supabase';

export default function Cases() {
  const [cases, setCases] = useState<CaseRow[]>([]);
  const [docs, setDocs] = useState<Record<string, DocumentRow[]>>({});
  const [open, setOpen] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', court: '', hearing_date: '', notes: '' });
  const [uploading, setUploading] = useState(false);

  async function loadCases() {
    const { data } = await supabase.from('cases').select('*').order('hearing_date');
    setCases(data || []);
  }

  async function loadDocs(caseId: string) {
    const { data } = await supabase.from('documents').select('*').eq('case_id', caseId);
    setDocs((prev) => ({ ...prev, [caseId]: data || [] }));
  }

  useEffect(() => {
    loadCases();
  }, []);

  async function addCase(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title || !form.hearing_date) return;
    const { error } = await supabase.from('cases').insert([form]);
    if (!error) {
      setForm({ title: '', court: '', hearing_date: '', notes: '' });
      setShowForm(false);
      loadCases();
    }
  }

  async function uploadFiles(caseId: string, files: FileList) {
    setUploading(true);
    for (const file of Array.from(files)) {
      const path = `${caseId}/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage.from('case-documents').upload(path, file);
      if (!uploadError) {
        await supabase.from('documents').insert([
          { case_id: caseId, file_name: file.name, storage_path: path, size_bytes: file.size },
        ]);
      }
    }
    await loadDocs(caseId);
    setUploading(false);
  }

  async function removeDoc(doc: DocumentRow) {
    await supabase.storage.from('case-documents').remove([doc.storage_path]);
    await supabase.from('documents').delete().eq('id', doc.id);
    loadDocs(doc.case_id);
  }

  async function openDoc(doc: DocumentRow) {
    const { data } = await supabase.storage.from('case-documents').createSignedUrl(doc.storage_path, 60);
    if (data?.signedUrl) window.open(data.signedUrl, '_blank');
  }

  return (
    <div>
      <button className="primary" onClick={() => setShowForm((s) => !s)} style={{ marginBottom: '1rem' }}>
        + New case
      </button>

      {showForm && (
        <form onSubmit={addCase} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: '1rem', marginBottom: '1rem', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <input placeholder="Case title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <input placeholder="Court" value={form.court} onChange={(e) => setForm({ ...form, court: e.target.value })} />
          <input type="date" value={form.hearing_date} onChange={(e) => setForm({ ...form, hearing_date: e.target.value })} required />
          <textarea placeholder="Notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} />
          <button type="submit" className="primary">Add case</button>
        </form>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {cases.map((c) => {
          const isOpen = open === c.id;
          return (
            <div key={c.id} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: '1rem 1.25rem' }}>
              <div
                style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer' }}
                onClick={() => {
                  const next = isOpen ? null : c.id;
                  setOpen(next);
                  if (next) loadDocs(next);
                }}
              >
                <div>
                  <p style={{ margin: 0, fontWeight: 500 }}>{c.title}</p>
                  <p style={{ margin: 0, fontSize: 13, color: 'var(--text-secondary)' }}>
                    {c.court || 'Court not set'} · {c.hearing_date}
                  </p>
                </div>
                <span style={{ color: 'var(--text-muted)' }}>{isOpen ? '▲' : '▼'}</span>
              </div>

              {isOpen && (
                <div style={{ marginTop: 12, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
                  {c.notes && <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{c.notes}</p>}
                  <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 8 }}>Documents</p>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
                    {(docs[c.id] || []).length === 0 && (
                      <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No documents uploaded.</p>
                    )}
                    {(docs[c.id] || []).map((d) => (
                      <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '6px 10px' }}>
                        <span onClick={() => openDoc(d)} style={{ cursor: 'pointer', color: 'var(--accent)' }}>{d.file_name}</span>
                        <button onClick={() => removeDoc(d)} style={{ border: 'none', padding: 0, background: 'none', color: 'var(--text-muted)' }}>✕</button>
                      </div>
                    ))}
                  </div>

                  <label style={{ fontSize: 13, color: 'var(--accent)', cursor: 'pointer' }}>
                    {uploading ? 'Uploading…' : '+ Upload documents'}
                    <input
                      type="file"
                      multiple
                      style={{ display: 'none' }}
                      onChange={(e) => e.target.files && uploadFiles(c.id, e.target.files)}
                    />
                  </label>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
